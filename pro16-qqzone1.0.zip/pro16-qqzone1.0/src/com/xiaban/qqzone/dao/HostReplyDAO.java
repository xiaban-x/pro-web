package com.xiaban.qqzone.dao;

public interface HostReplyDAO {
}

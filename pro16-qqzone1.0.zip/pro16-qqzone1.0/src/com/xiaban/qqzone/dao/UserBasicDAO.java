package com.xiaban.qqzone.dao;

import com.xiaban.qqzone.pojo.Topic;
import com.xiaban.qqzone.pojo.UserBasic;

import java.util.List;

public interface UserBasicDAO {
    //1.根据登录的账号密码查看信息
    public UserBasic getUserBasic(String id,String psw);
    //2.获取指定用户的所有好友列表
    public List<UserBasic> getUserBasicList(UserBasic userBasic);
    //3.根据id查询UserBasic的信息
    public UserBasic getUserBasicById(Integer id);
}

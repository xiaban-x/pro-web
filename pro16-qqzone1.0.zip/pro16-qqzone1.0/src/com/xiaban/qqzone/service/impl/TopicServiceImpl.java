package com.xiaban.qqzone.service.impl;

import com.xiaban.qqzone.dao.TopicDAO;
import com.xiaban.qqzone.pojo.Topic;
import com.xiaban.qqzone.pojo.UserBasic;
import com.xiaban.qqzone.service.TopicService;

import java.util.List;

public class TopicServiceImpl implements TopicService {

    private TopicDAO topicDAO = null;
    @Override
    public List<Topic> getTopicList(UserBasic userBasic) {

        return topicDAO.getTopicList(userBasic);
    }
}

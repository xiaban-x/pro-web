package com.xiaban.qqzone.service;

import com.xiaban.qqzone.pojo.Topic;
import com.xiaban.qqzone.pojo.UserBasic;

import java.util.List;

public interface TopicService {
    //查询特定用户的日志
    List<Topic> getTopicList(UserBasic userBasic);
}

package com.xiaban.qqzone.controller;

import com.xiaban.qqzone.pojo.Topic;
import com.xiaban.qqzone.pojo.UserBasic;
import com.xiaban.qqzone.service.TopicService;
import com.xiaban.qqzone.service.UserBasicService;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;
import java.util.List;

public class UserController {

    private UserBasicService userBasicService;
    private TopicService topicService;
    public String login(String loginId, String pwd, HttpSession session){
        //1.登录验证
        UserBasic userBasic = userBasicService.login(loginId,pwd);
        if (userBasic!=null){
            //2.得到好友列表
            List<UserBasic> friendList = userBasicService.getFriendList(userBasic);
            //3.获得日志列表
            List<Topic> topicList = topicService.getTopicList(userBasic);

            userBasic.setFriendList(friendList);
            userBasic.setTopicList(topicList);

            session.setAttribute("userBasic",userBasic);
            return "index";
        }else{
            return "login";
        }
    }
}

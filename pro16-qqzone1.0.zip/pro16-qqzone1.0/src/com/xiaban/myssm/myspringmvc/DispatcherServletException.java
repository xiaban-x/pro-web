package com.xiaban.myssm.myspringmvc;

public class DispatcherServletException extends RuntimeException{
    public DispatcherServletException(String message) {
        super(message);
    }
}

package com.xiaban.myssm.io;

public interface BeanFactory {
    Object getBean(String id);
}
